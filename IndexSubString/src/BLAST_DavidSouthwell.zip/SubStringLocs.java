import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

/**
 *  BLAST <br>
 *
 *  bundles a dna substring along with the list of its locations
 *  into a hash table
 *  <br> <br>
 *  Created: <br>
 *     [April 17 2017], [David Southwell]<br>
 *     With assistance from:  [Raphael Wieland]<br>
 *  Modifications: <br>
 *     [the date], [your name(s)], [the reason]<br>
 *
 *  @author [David Southwell]   []
 *  @version [June 9 2017]
 */
public class SubStringLocs
{
    // State: instance variables and shared class variables go here.
    private String subString;
    private ArrayList<Location> locArray;

    // Constructors

    /**
     * Constructs a new object of this class.
     *
     *      @param   subString   initial value for the object's state
     *      @param   loc - Location
     */
    public SubStringLocs(String subString, Location loc)
    {
        locArray = new ArrayList<Location>();
       this.subString = subString;
       locArray.add(loc);
    }
    public void addLoc(Location location){
        locArray.add(location);
    }
    public String getSubString(){
        return this.subString;
    }
    public String toString(){
        String string = subString;
        for(Location l: locArray)
            string += l.toString()+" ";
        return string;
    }


}