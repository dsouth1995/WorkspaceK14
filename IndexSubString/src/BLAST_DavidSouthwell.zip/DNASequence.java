/**
 *  BLAST <br>
 *
 *  builds dna sequence object that holds id, description,
 *  and the nucleotide sequence
 *  <br> <br>
 *  Created: <br>
 *     [April 17 2017], [David Southwell]<br>
 *     With assistance from:  []<br>
 *  Modifications: <br>
 *     [the date], [your name(s)], [the reason]<br>
 *
 *  @author [David Southwell]   []
 *  @version [April 17 2017]
 */
public class DNASequence {
    private String id;
    private String description;
    public String sequence;
    public DNASequence(String id, String description, String sequence) {
        this.id = id;
        this.description = description;
        this.sequence = sequence;
    }
    public String toString(){
        String dna = new String("GenInfo Indent:"+id+", Description:"+description+", Sequence String:"+sequence);
        return dna;
    }
}
