
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

/**
 *  BLAST <br>
 *
 *  To keep track of locations, this class will
 *  hold a pair of integers indicating (a) the DNA sequence string,
 *  and (b) the starting location of the substring within the sequence string.
 *  <br> <br>
 *  Created: <br>
 *     [April 17 2017], [David Southwell]<br>
 *     With assistance from:  []<br>
 *  Modifications: <br>
 *     [the date], [your name(s)], [the reason]<br>
 *
 *  @author [David Southwell]   []
 *  @version [April 17 2017]
 */
public class Location
{
    //instance variables.
    private int seq;
    private int startLoc;
    public ArrayList<DNADataReader> seqList;




    //private DNASequence seqObj = dataArray.get(i);



    // Constructors

    /**
     * Constructs a new object of this class.
     *
     *      @param   seq    index of sequence string
     *      @param   startLoc    index of substring (ex:agct)
     */
    public Location(int seq, int startLoc)
    {


        // initialise instance variables
        this.seq = seq;
        this.startLoc = startLoc;
    }

    // Methods

    public String toString(){
        String seqLoc = new String("("+seq+","+startLoc+")");
        return seqLoc;
    }



}