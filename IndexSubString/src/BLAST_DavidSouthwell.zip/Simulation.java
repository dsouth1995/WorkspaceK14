import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

/**
 *  BLAST <br>
 *
 *   1.Compiles a list of high scoring words
 *   2.Scans Database for hits
 *   3.Tries to extend length of matches or "hits"
 *   4.Reports Data regarding number of and location
 *   of matches between the query data and the virus dna data
 *  <br> <br>
 *  Created: <br>
 *     [June 9 2017], [David Southwell]<br>
 *     With assistance from:  [Raphael Wieland]<br>
 *  Modifications: <br>
 *     [the date], [your name(s)], [the reason]<br>
 *
 *  @author [David Southwell]   []
 *  @version [June 9 2017]
 */
public class Simulation {
    int subStringLength;
    int count = 0;
    Location loc;
    DNADataReader dObj;
    DNASequence nucSeq;
    ArrayList<DNASequence> seqArray;
    ArrayList<SubStringLocs> hashTable;
    String suggestedD = new String("TestData.txt");
    String suggestedQ = new String("TestQueries.txt");

    public Simulation(String dfile, String qfile, int subStringLength){
        ValidatedInputReader.getString(dfile, suggestedD);
        ValidatedInputReader.getString(qfile, suggestedQ);
        dObj = new DNADataReader(dfile);
        qObj = new QueryReader(qfile);
        seqArray = new ArrayList<DNASequence>(dObj.readData());
        queryArray = new ArrayList<DNASequence>(qObj.readData());
        hashTable = new ArrayList<SubStringLocs>();
        this.subStringLength = subStringLength;
    }
    //Index the database: Read the virus DNA sequences from a data file;
    // choose an appropriate data structure to hold this information.
    // Create a hash table to contain all of the n-letter words found in the sequences,
    // and their locations within the database (i.e., which sequence and the
    // starting position(s) of this word in the sequence).
    public void indexDataBase(){

        for(DNASequence s: seqArray){
            // Read lines until hitting a null or blank line.
            String nextLine = s.sequence;
            for(int i = 0; i<nextLine.length()-subStringLength; i++) {
               String subString = nextLine.substring(i,i+subStringLength);
               System.out.println("Substring: "+subString);
               if (hashTable.size()==0){
                   hashTable.add(new SubStringLocs(subString,new Location(count,i)));
               }else{
                   boolean found = false;
                for (int j = 0; j<hashTable.size(); j++){

                    if (hashTable.get(j).getSubString().equals(subString)){
                        hashTable.get(j).addLoc(new Location(count,i));
                        found=true;
                        System.out.println("SEQUENCE "+count+":"+hashTable.get(j).toString());
                    }

                }
                if (found==false)
                    hashTable.add(new SubStringLocs(subString,new Location(count,i)));
               }

            }count++;

        }

    }
    //Scan the query sequence: For each n-letter word in the query sequence,
    // check if it is in the hash table. If it is in the table,
    // attempt to extend this hit.
    public boolean findQuery(DNASequence query){

        for(DNASequence s: query){
            // Read lines until hitting a null or blank line.
            String nextLine = s.sequence;
            for(int i = 0; i<nextLine.length()-subStringLength; i++) {
                String subString = nextLine.substring(i,i+subStringLength);
                System.out.println("Substring: "+subString);
                if (hashTable.size()==0){
                    return false;
                }else{
                    boolean found = false;
                    for (int j = 0; j<hashTable.size(); j++){

                        if (hashTable.get(j).getSubString().equals(subString)){
                            extendHit();
                            found=true;
                            System.out.println("SEQUENCE "+count+":"+hashTable.get(j).toString());
                        }

                    }
                    if (found==false)
                       return false;
                }

            }count++;

        }return false;

    }
    //Extend the hits: Once we have a obtained a hit with a word in the hash table, go to the first
    // location indicated in a database sequence, and begin to try to extend the match to make a
    // longer matching sequence. (Note, with this algorithm, we are just looking for exact matches
    // between sequences.) When we get to a mismatch, stop extending. Once the extension has been stopped,
    // check if the length of the match is longer than some prescribed value. If it is, and the match is
    // not part of a longer match already being saved, save this match for reporting.
    public String extendHit(){
    }

}
