/**
 * Created by dsout on 6/8/2017.
 */
public class ExtremeValueCalculator implements NodeVisitor {

    @Override
    public void visit(Object data) {

    }

    @Override
    public int sum() {
        return 0;
    }
}
